export interface SiteSettings {
  siteName: string;
  bannerImage: string;
  funnelText: string;
  logo: string;
}