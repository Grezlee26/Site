"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useTranslations } from 'next-intl';
import { Post } from "@/lib/types/post";
import { PostCard } from "@/components/post-card";

interface PopularPostsGridProps {
  className?: string;
}

export function PopularPostsGrid({ className }: PopularPostsGridProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const t = useTranslations('popular');

  useEffect(() => {
    async function fetchPopularPosts() {
      try {
        const response = await fetch('/api/posts/popular');
        if (!response.ok) throw new Error();
        const data = await response.json();
        setPosts(data);
      } catch (error) {
        console.error('Failed to fetch popular posts:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchPopularPosts();
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-64 bg-muted animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  if (!posts.length) return null;

  return (
    <section className={`py-12 ${className}`}>
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-2xl font-bold text-center mb-8">
            {t('title')}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}