"use client";

import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { cn } from "@/lib/utils";

interface PostContentProps {
  content: string;
}

export function PostContent({ content }: PostContentProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="prose dark:prose-invert max-w-none"
    >
      <ReactMarkdown
        components={{
          h1: ({ className, ...props }) => (
            <h1 className={cn("text-3xl font-bold mt-8 mb-4", className)} {...props} />
          ),
          h2: ({ className, ...props }) => (
            <h2 className={cn("text-2xl font-bold mt-8 mb-4", className)} {...props} />
          ),
          h3: ({ className, ...props }) => (
            <h3 className={cn("text-xl font-bold mt-6 mb-3", className)} {...props} />
          ),
          p: ({ className, ...props }) => (
            <p className={cn("leading-7 mb-4", className)} {...props} />
          ),
          ul: ({ className, ...props }) => (
            <ul className={cn("list-disc list-inside mb-4 space-y-2", className)} {...props} />
          ),
          ol: ({ className, ...props }) => (
            <ol className={cn("list-decimal list-inside mb-4 space-y-2", className)} {...props} />
          ),
          blockquote: ({ className, ...props }) => (
            <blockquote 
              className={cn(
                "border-l-4 border-primary pl-4 italic my-6",
                className
              )} 
              {...props} 
            />
          ),
          code: ({ className, ...props }) => (
            <code 
              className={cn(
                "bg-muted px-1.5 py-0.5 rounded text-sm",
                className
              )} 
              {...props} 
            />
          ),
          pre: ({ className, ...props }) => (
            <pre 
              className={cn(
                "bg-muted p-4 rounded-lg overflow-x-auto",
                className
              )} 
              {...props} 
            />
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </motion.div>
  );
}