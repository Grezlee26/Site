"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

interface Tag {
  id: string;
  name: string;
  slug: string;
}

interface PostTagsProps {
  tags: Tag[];
}

export function PostTags({ tags }: PostTagsProps) {
  if (!tags.length) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <h3 className="text-lg font-semibold mb-4">Tags</h3>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <Link key={tag.id} href={`/tag/${tag.slug}`}>
            <Badge variant="secondary" className="hover:bg-secondary/80">
              #{tag.name}
            </Badge>
          </Link>
        ))}
      </div>
    </motion.div>
  );
}