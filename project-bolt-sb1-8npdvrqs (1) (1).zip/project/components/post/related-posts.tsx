"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useLocale } from 'next-intl';
import { Post } from "@/lib/types/post";
import { PostCard } from "@/components/post-card";

interface RelatedPostsProps {
  postId: string;
}

export function RelatedPosts({ postId }: RelatedPostsProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const locale = useLocale();

  useEffect(() => {
    async function fetchRelatedPosts() {
      try {
        const response = await fetch(`/api/posts/${postId}/related`);
        if (!response.ok) throw new Error();
        const data = await response.json();
        setPosts(data);
      } catch (error) {
        console.error('Failed to fetch related posts:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchRelatedPosts();
  }, [postId]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-64 bg-muted animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  if (!posts.length) return null;

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="mt-16 pt-16 border-t"
    >
      <h2 className="text-2xl font-bold mb-8">Похожие статьи</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>
    </motion.section>
  );
}