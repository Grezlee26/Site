"use client";

export function PostSkeleton() {
  return (
    <div className="animate-pulse">
      <div className="relative min-h-[60vh] w-full bg-muted">
        <div className="absolute bottom-0 w-full p-12">
          <div className="container max-w-4xl mx-auto">
            <div className="h-12 w-3/4 bg-muted-foreground/20 rounded mb-6" />
            <div className="flex gap-6">
              <div className="h-4 w-32 bg-muted-foreground/20 rounded" />
              <div className="h-4 w-32 bg-muted-foreground/20 rounded" />
            </div>
          </div>
        </div>
      </div>

      <div className="container max-w-4xl mx-auto px-4 py-12">
        <div className="space-y-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-4 bg-muted rounded w-full" />
          ))}
          <div className="h-4 bg-muted rounded w-2/3" />
        </div>
      </div>
    </div>
  );
}