"use client";

import { motion } from "framer-motion";
import { useLocale } from 'next-intl';
import { User, Calendar } from "lucide-react";

interface PostHeaderProps {
  title: string;
  image: string;
  author: { name: string | null };
  date: string;
}

export function PostHeader({ title, image, author, date }: PostHeaderProps) {
  const locale = useLocale();

  return (
    <div className="relative min-h-[60vh] w-full overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url('${image}')` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      </div>

      <motion.div 
        className="relative h-full flex items-end"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container max-w-4xl mx-auto px-4 pb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            {title}
          </h1>
          
          <div className="flex items-center gap-6 text-muted-foreground">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>{author.name || "Anonymous"}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <time dateTime={date}>
                {new Date(date).toLocaleDateString(locale, {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </time>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}