"use client";

import { useState } from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSession } from "next-auth/react";
import { toast } from "sonner";

interface LikeButtonProps {
  postId: string;
  initialLiked: boolean;
  initialCount: number;
  enabled?: boolean;
}

export function LikeButton({ 
  postId, 
  initialLiked, 
  initialCount,
  enabled = true 
}: LikeButtonProps) {
  const { data: session } = useSession();
  const [liked, setLiked] = useState(initialLiked);
  const [count, setCount] = useState(initialCount);
  const [loading, setLoading] = useState(false);

  if (!enabled) return null;

  async function toggleLike() {
    if (!session) {
      toast.error("Войдите, чтобы поставить лайк");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: liked ? "DELETE" : "POST",
      });

      if (!response.ok) throw new Error();

      setLiked(!liked);
      setCount(prev => liked ? prev - 1 : prev + 1);
    } catch (error) {
      toast.error("Не удалось обновить лайк");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      className="flex items-center gap-2"
      onClick={toggleLike}
      disabled={loading}
    >
      <Heart 
        className={`w-5 h-5 ${liked ? "fill-current text-red-500" : ""}`} 
      />
      <span>{count}</span>
    </Button>
  );
}