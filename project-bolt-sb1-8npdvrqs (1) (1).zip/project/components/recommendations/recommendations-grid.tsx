"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { motion } from "framer-motion";
import { Post } from "@/lib/types/post";
import { PostCard } from "@/components/post-card";
import { usePreferences } from "@/lib/hooks/use-preferences";

export function RecommendationsGrid() {
  const { data: session } = useSession();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [enabled, setEnabled] = useState(true);
  const guestId = localStorage.getItem('guest_id');

  useEffect(() => {
    async function fetchRecommendations() {
      try {
        const params = new URLSearchParams();
        if (!session && guestId) {
          params.append('guestId', guestId);
        }

        const response = await fetch(`/api/recommendations?${params}`);
        if (!response.ok) throw new Error();
        const data = await response.json();
        
        setPosts(data.posts);
        setEnabled(data.enabled);
      } catch (error) {
        console.error('Failed to fetch recommendations:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchRecommendations();
  }, [session, guestId]);

  if (!enabled || loading || !posts.length) {
    return null;
  }

  return (
    <section className="py-12 bg-muted/30">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-2xl font-bold text-center mb-8">
            Рекомендуемые статьи
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}