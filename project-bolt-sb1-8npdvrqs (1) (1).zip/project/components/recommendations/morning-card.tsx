"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ThumbsUp, ThumbsDown, RefreshCw } from "lucide-react";
import { toast } from "sonner";

interface MorningCardProps {
  recommendation: string;
  onRefresh: () => void;
}

export function MorningCard({ recommendation, onRefresh }: MorningCardProps) {
  const [loading, setLoading] = useState(false);

  async function handleFeedback(feedback: number) {
    setLoading(true);
    try {
      const response = await fetch("/api/recommendations/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ feedback })
      });

      if (!response.ok) throw new Error();
      toast.success("Thank you for your feedback!");
    } catch (error) {
      toast.error("Failed to save feedback");
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Morning Recommendation
            <Button
              variant="ghost"
              size="icon"
              onClick={onRefresh}
              disabled={loading}
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-lg mb-6">{recommendation}</p>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleFeedback(-1)}
              disabled={loading}
            >
              <ThumbsDown className="w-4 h-4 mr-2" />
              Not Helpful
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleFeedback(1)}
              disabled={loading}
            >
              <ThumbsUp className="w-4 h-4 mr-2" />
              Helpful
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}