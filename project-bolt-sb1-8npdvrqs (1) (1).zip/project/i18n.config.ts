export default {
  defaultLocale: 'en',
  locales: ['en', 'ru']
} as const;