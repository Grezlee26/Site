"use client";

import { useSearchParams } from "next/navigation";
import { SearchInput } from "@/components/search/search-input";
import { SearchResults } from "@/components/search/search-results";
import { useTranslations } from 'next-intl';

export default function SearchPage() {
  const searchParams = useSearchParams();
  const query = searchParams.get("q") || "";
  const t = useTranslations('search');

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto mb-12">
        <h1 className="text-3xl font-bold text-center mb-8">{t('title')}</h1>
        <SearchInput size="lg" />
      </div>

      {query ? (
        <SearchResults query={query} />
      ) : (
        <p className="text-center text-muted-foreground">
          {t('no_query')}
        </p>
      )}
    </div>
  );
}