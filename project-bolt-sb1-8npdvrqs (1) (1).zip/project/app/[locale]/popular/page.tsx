"use client";

import { PopularPostsGrid } from "@/components/popular/popular-posts-grid";

export default function PopularPage() {
  return (
    <div className="min-h-screen">
      <div className="py-12 bg-muted/30">
        <div className="container px-4">
          <h1 className="text-4xl font-bold text-center">
            Популярные статьи
          </h1>
        </div>
      </div>
      
      <PopularPostsGrid className="bg-background" />
    </div>
  );
}