import { Inter } from 'next/font/google';
import { notFound } from 'next/navigation';
import ClientProvider from '@/components/client-provider';
import '../globals.css';

const inter = Inter({ subsets: ['latin'] });

async function getMessages(locale: string) {
  try {
    return (await import(`../../messages/${locale}.json`)).default;
  } catch (error) {
    notFound();
  }
}

export default async function LocaleLayout({
  children,
  params: { locale }
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const messages = await getMessages(locale);

  return (
    <html lang={locale} suppressHydrationWarning>
      <body className={inter.className}>
        <ClientProvider locale={locale} messages={messages}>
          {children}
        </ClientProvider>
      </body>
    </html>
  );
}