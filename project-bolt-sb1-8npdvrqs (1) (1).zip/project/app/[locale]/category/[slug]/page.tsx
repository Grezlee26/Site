"use client";

import { useEffect, useState } from "react";
import { useTranslations } from 'next-intl';
import { notFound } from "next/navigation";
import { PostGrid } from "@/components/post-grid";
import { CategoryHeader } from "@/components/category/category-header";
import { Category } from "@/lib/types/category";

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const [category, setCategory] = useState<Category | null>(null);
  const [loading, setLoading] = useState(true);
  const t = useTranslations('category');

  useEffect(() => {
    async function fetchCategory() {
      try {
        const response = await fetch(`/api/categories/${params.slug}`);
        if (!response.ok) throw new Error();
        const data = await response.json();
        setCategory(data);
      } catch (error) {
        notFound();
      } finally {
        setLoading(false);
      }
    }

    fetchCategory();
  }, [params.slug]);

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-48 bg-muted" />
        <div className="container mx-auto px-4 py-12">
          <div className="h-8 w-64 bg-muted rounded mb-8 mx-auto" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-64 bg-muted rounded" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!category) {
    return notFound();
  }

  return (
    <div>
      <CategoryHeader category={category} />
      <div className="container mx-auto px-4 py-12">
        <PostGrid searchQuery={`category:${params.slug}`} />
      </div>
    </div>
  );
}