"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { HabitList } from "@/components/habits/habit-list";
import { CreateHabitDialog } from "@/components/habits/create-habit-dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function HabitsPage() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);

  if (!session) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-center text-muted-foreground">
          Please sign in to manage your habits
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Habits</h1>
        <Button onClick={() => setOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Habit
        </Button>
      </div>

      <HabitList />
      <CreateHabitDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}