"use client";

import { useEffect, useState } from "react";
import { useLocale } from 'next-intl';
import { notFound } from "next/navigation";
import { Metadata } from "next";
import { PostHeader } from "@/components/post/post-header";
import { PostContent } from "@/components/post/post-content";
import { PostTags } from "@/components/post/post-tags";
import { PostSkeleton } from "@/components/post/post-skeleton";
import { Post } from "@/lib/types/post";

export default function PostPage({ params }: { params: { slug: string } }) {
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);
  const locale = useLocale();

  useEffect(() => {
    async function fetchPost() {
      try {
        const response = await fetch(`/api/posts/${params.slug}`);
        if (!response.ok) throw new Error();
        const data = await response.json();
        setPost(data);
      } catch (error) {
        notFound();
      } finally {
        setLoading(false);
      }
    }

    fetchPost();
  }, [params.slug]);

  if (loading) {
    return <PostSkeleton />;
  }

  if (!post) {
    return notFound();
  }

  return (
    <article className="min-h-screen">
      <PostHeader 
        title={post.title[locale]} 
        image={post.featuredImage}
        author={post.author}
        date={post.createdAt}
      />
      
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <PostContent content={post.content[locale]} />
        
        <div className="mt-8 pt-8 border-t">
          <PostTags tags={post.tags} />
        </div>
      </div>
    </article>
  );
}