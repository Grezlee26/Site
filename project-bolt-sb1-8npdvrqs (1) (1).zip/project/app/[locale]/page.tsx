import { Suspense } from 'react';
import { HeroBanner } from '@/components/home/hero-banner';
import { FeaturedPosts } from '@/components/home/featured-posts';
import { LatestPosts } from '@/components/home/latest-posts';
import { SearchBar } from '@/components/search-bar';
import { SiteSettings } from '@/lib/types/settings';

async function getSettings(): Promise<SiteSettings> {
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/settings`, {
    next: { revalidate: 60 } // Revalidate every minute
  });
  
  if (!res.ok) {
    throw new Error('Failed to fetch settings');
  }
  
  return res.json();
}

export default async function HomePage() {
  const settings = await getSettings();

  return (
    <div className="min-h-screen">
      <HeroBanner settings={settings} />
      
      <div className="container mx-auto px-4 py-12">
        <Suspense fallback={<div className="h-10 w-full max-w-xl mx-auto bg-muted animate-pulse rounded-md" />}>
          <SearchBar />
        </Suspense>
      </div>

      <Suspense fallback={<div className="h-96 bg-muted animate-pulse" />}>
        <FeaturedPosts />
      </Suspense>

      <Suspense fallback={<div className="h-96 bg-muted animate-pulse" />}>
        <LatestPosts />
      </Suspense>
    </div>
  );
}