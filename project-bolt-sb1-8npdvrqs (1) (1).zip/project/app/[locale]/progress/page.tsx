"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { ProgressCharts } from "@/components/progress/progress-charts";
import { ProgressStats } from "@/components/progress/progress-stats";
import { ProgressFilters } from "@/components/progress/progress-filters";

export default function ProgressPage() {
  const { data: session } = useSession();
  const [period, setPeriod] = useState<"week" | "month">("week");

  if (!session) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-center text-muted-foreground">
          Please sign in to view your progress
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Progress</h1>
        <ProgressFilters period={period} onPeriodChange={setPeriod} />
      </div>

      <div className="grid gap-6">
        <ProgressStats period={period} />
        <ProgressCharts period={period} />
      </div>
    </div>
  );
}