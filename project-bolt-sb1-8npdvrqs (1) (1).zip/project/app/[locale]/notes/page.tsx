"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { NoteList } from "@/components/notes/note-list";
import { CreateNoteDialog } from "@/components/notes/create-note-dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function NotesPage() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);

  if (!session) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-center text-muted-foreground">
          Please sign in to manage your notes
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">My Notes</h1>
        <Button onClick={() => setOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Note
        </Button>
      </div>

      <NoteList />
      <CreateNoteDialog open={open} onOpenChange={setOpen} />
    </div>
  );
}