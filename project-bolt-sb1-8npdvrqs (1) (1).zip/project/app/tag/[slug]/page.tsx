"use client"

import { useEffect, useState } from "react"
import { notFound } from "next/navigation"
import { PostGrid } from "@/components/post-grid"

interface Tag {
  id: string
  name: string
  description?: string
}

export default function TagPage({ params }: { params: { slug: string } }) {
  const [tag, setTag] = useState<Tag | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTag = async () => {
      try {
        const res = await fetch(`/api/tags/${params.slug}`)
        if (!res.ok) {
          throw new Error("Tag not found")
        }
        const data = await res.json()
        setTag(data)
      } catch (error) {
        notFound()
      } finally {
        setLoading(false)
      }
    }

    fetchTag()
  }, [params.slug])

  if (loading) {
    return <div>Loading...</div>
  }

  if (!tag) {
    return notFound()
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">#{tag.name}</h1>
        {tag.description && (
          <p className="text-lg text-muted-foreground">{tag.description}</p>
        )}
      </div>
      <PostGrid searchQuery={`tag:${tag.slug}`} />
    </div>
  )
}