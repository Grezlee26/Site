"use client"

import { useSearchParams } from "next/navigation"
import { PostGrid } from "@/components/post-grid"
import { SearchInput } from "@/components/search/search-input"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto mb-12">
        <h1 className="text-3xl font-bold text-center mb-8">Поиск</h1>
        <SearchInput />
      </div>

      {query ? (
        <>
          <h2 className="text-xl text-muted-foreground text-center mb-8">
            Результаты поиска для &quot;{query}&quot;
          </h2>
          <PostGrid searchQuery={query} />
        </>
      ) : (
        <p className="text-center text-muted-foreground">
          Введите поисковый запрос выше
        </p>
      )}
    </div>
  )
}