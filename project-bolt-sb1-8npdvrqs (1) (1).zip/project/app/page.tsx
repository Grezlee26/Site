"use client"

import { useState } from "react"
import { Hero } from "@/components/hero"
import { PostGrid } from "@/components/post-grid"
import { SearchBar } from "@/components/search-bar"

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="min-h-screen">
      <Hero />
      
      <div className="container mx-auto px-4 py-8">
        <SearchBar onSearch={setSearchQuery} />

        <div className="max-w-2xl mx-auto my-12 text-center">
          <p className="text-lg text-muted-foreground">
            Откройте для себя мир увлекательных статей, созданных с помощью искусственного интеллекта. 
            Каждая статья - это уникальное путешествие в мир знаний и идей.
          </p>
        </div>

        <PostGrid searchQuery={searchQuery} />
      </div>
    </div>
  )
}