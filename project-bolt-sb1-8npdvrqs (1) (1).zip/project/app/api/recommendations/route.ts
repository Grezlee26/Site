import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../auth/[...nextauth]/route";

export async function GET(request: Request) {
  try {
    // Check if recommendations are enabled
    const [enabledSetting, countSetting] = await Promise.all([
      prisma.setting.findUnique({
        where: { key: "recommendations_enabled" }
      }),
      prisma.setting.findUnique({
        where: { key: "recommendations_count" }
      })
    ]);

    if (enabledSetting?.value !== "true") {
      return NextResponse.json({ 
        enabled: false,
        posts: [] 
      });
    }

    const limit = countSetting ? parseInt(countSetting.value, 10) : 6;
    const session = await getServerSession(authOptions);
    const { searchParams } = new URL(request.url);
    const guestId = searchParams.get("guestId");

    // Get recommended posts using the custom function
    const posts = await prisma.$queryRaw`
      SELECT * FROM get_recommended_posts(
        ${session?.user?.id || null}::uuid,
        ${guestId || null}::text,
        ${limit}::integer
      )
    `;

    return NextResponse.json({
      enabled: true,
      posts
    });
  } catch (error) {
    console.error("[RECOMMENDATIONS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch recommendations" },
      { status: 500 }
    );
  }
}