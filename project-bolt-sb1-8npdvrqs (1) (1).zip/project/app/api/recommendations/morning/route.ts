import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { generateMorningRecommendation } from "@/lib/ai/recommendation-generator";
import { authOptions } from "../../auth/[...nextauth]/route";
import { checkApiLimit, incrementApiUsage } from "@/lib/db/api-usage";

export async function GET() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    // Check API usage limit
    const canUseApi = await checkApiLimit(session.user.id, 'gpt');
    if (!canUseApi) {
      return NextResponse.json(
        { error: "Daily API limit reached" },
        { status: 429 }
      );
    }

    const recommendation = await generateMorningRecommendation(session.user.id);
    await incrementApiUsage(session.user.id, 'gpt');

    return NextResponse.json({ recommendation });
  } catch (error) {
    console.error("[MORNING_RECOMMENDATION]", error);
    return NextResponse.json(
      { error: "Failed to generate recommendation" },
      { status: 500 }
    );
  }
}