import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { recommendationId, feedback } = await request.json();

    const recommendation = await prisma.recommendation.findUnique({
      where: { id: recommendationId }
    });

    if (!recommendation || recommendation.userId !== session.user.id) {
      return NextResponse.json(
        { error: "Recommendation not found" },
        { status: 404 }
      );
    }

    await prisma.recommendation.update({
      where: { id: recommendationId },
      data: { feedback }
    });

    // Update user preferences based on feedback
    if (feedback > 0) {
      await prisma.userPreference.upsert({
        where: {
          userId_type: {
            userId: session.user.id,
            type: recommendation.category || 'GENERAL'
          }
        },
        update: {
          score: { increment: 1 }
        },
        create: {
          userId: session.user.id,
          type: recommendation.category || 'GENERAL',
          score: 1
        }
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[RECOMMENDATION_FEEDBACK]", error);
    return NextResponse.json(
      { error: "Failed to save feedback" },
      { status: 500 }
    );
  }
}