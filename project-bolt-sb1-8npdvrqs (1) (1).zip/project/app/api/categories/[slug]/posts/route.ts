import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  request: Request,
  { params }: { params: { slug: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "6");

    const posts = await prisma.post.findMany({
      where: {
        published: true,
        categories: {
          some: {
            slug: params.slug,
            isActive: true
          }
        }
      },
      include: {
        author: {
          select: {
            name: true
          }
        },
        tags: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      },
      take: limit,
      skip: (page - 1) * limit,
      orderBy: {
        createdAt: "desc"
      }
    });

    const total = await prisma.post.count({
      where: {
        published: true,
        categories: {
          some: {
            slug: params.slug,
            isActive: true
          }
        }
      }
    });

    return NextResponse.json({
      posts,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("[CATEGORY_POSTS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch category posts" },
      { status: 500 }
    );
  }
}