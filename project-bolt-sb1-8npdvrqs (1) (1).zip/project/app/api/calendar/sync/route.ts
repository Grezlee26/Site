import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { GoogleCalendarService } from "@/lib/google-calendar";
import { authOptions } from "../../auth/[...nextauth]/route";

const calendarService = new GoogleCalendarService();

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { type, id } = await request.json();

    // Get user's Google Calendar token
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { googleCalendarToken: true }
    });

    if (!user?.googleCalendarToken) {
      return NextResponse.json(
        { error: "Google Calendar not connected", authUrl: calendarService.getAuthUrl() },
        { status: 403 }
      );
    }

    let event;
    if (type === 'habit') {
      const habit = await prisma.habit.findUnique({
        where: { id }
      });

      if (!habit) {
        return NextResponse.json(
          { error: "Habit not found" },
          { status: 404 }
        );
      }

      // Create recurring event for habit
      const startTime = new Date();
      startTime.setHours(9, 0, 0, 0); // 9 AM

      const endTime = new Date(startTime);
      endTime.setHours(10, 0, 0, 0); // 10 AM

      event = await calendarService.addEvent(user.googleCalendarToken, {
        summary: `🎯 ${habit.name}`,
        description: habit.description,
        startTime,
        endTime
      });
    }

    return NextResponse.json({ success: true, event });
  } catch (error) {
    console.error("[CALENDAR_SYNC]", error);
    return NextResponse.json(
      { error: "Failed to sync with calendar" },
      { status: 500 }
    );
  }
}