import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../auth/[...nextauth]/route";
import { subDays, startOfDay, endOfDay } from "date-fns";

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") || "week";
    const days = period === "month" ? 30 : 7;
    const startDate = startOfDay(subDays(new Date(), days));

    // Get daily entries and habits
    const [entries, habits] = await Promise.all([
      prisma.entry.findMany({
        where: {
          userId: session.user.id,
          createdAt: {
            gte: startDate,
            lte: endOfDay(new Date())
          }
        },
        orderBy: { createdAt: "asc" }
      }),
      prisma.habit.findMany({
        where: {
          userId: session.user.id,
          lastChecked: {
            gte: startDate,
            lte: endOfDay(new Date())
          }
        }
      })
    ]);

    // Group data by date
    const data = [...Array(days)].map((_, i) => {
      const date = subDays(new Date(), i);
      const dayStart = startOfDay(date);
      const dayEnd = endOfDay(date);

      const dayEntries = entries.filter(entry => 
        entry.createdAt >= dayStart && entry.createdAt <= dayEnd
      );

      const dayHabits = habits.filter(habit =>
        habit.lastChecked && habit.lastChecked >= dayStart && habit.lastChecked <= dayEnd
      );

      return {
        date: date.toISOString(),
        mood: dayEntries.reduce((acc, entry) => acc + (entry.mood || 0), 0) / dayEntries.length || 0,
        habits: dayHabits.length
      };
    }).reverse();

    return NextResponse.json(data);
  } catch (error) {
    console.error("[PROGRESS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch progress data" },
      { status: 500 }
    );
  }
}