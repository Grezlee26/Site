import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";
import { subDays, startOfDay, endOfDay } from "date-fns";

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") || "week";
    const days = period === "month" ? 30 : 7;
    const startDate = startOfDay(subDays(new Date(), days));

    // Get entries and habits for the period
    const [entries, habits] = await Promise.all([
      prisma.entry.findMany({
        where: {
          userId: session.user.id,
          createdAt: {
            gte: startDate,
            lte: endOfDay(new Date())
          }
        }
      }),
      prisma.habit.findMany({
        where: {
          userId: session.user.id
        }
      })
    ]);

    // Calculate stats
    const averageMood = entries.reduce((acc, entry) => acc + (entry.mood || 0), 0) / entries.length || 0;
    const moodTrend = calculateMoodTrend(entries);
    const totalHabits = habits.length;
    const completionRate = calculateCompletionRate(habits, days);
    const longestStreak = Math.max(...habits.map(h => h.streakCount));

    return NextResponse.json({
      averageMood,
      moodTrend,
      totalHabits,
      completionRate,
      longestStreak
    });
  } catch (error) {
    console.error("[PROGRESS_STATS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch progress stats" },
      { status: 500 }
    );
  }
}

function calculateMoodTrend(entries: any[]): "up" | "down" | "stable" {
  if (entries.length < 2) return "stable";

  const recentMoods = entries
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 2)
    .map(e => e.mood || 0);

  const diff = recentMoods[0] - recentMoods[1];
  if (diff > 0.5) return "up";
  if (diff < -0.5) return "down";
  return "stable";
}

function calculateCompletionRate(habits: any[], days: number): number {
  if (!habits.length) return 0;

  const totalPossible = habits.length * days;
  const completed = habits.reduce((acc, habit) => acc + habit.streakCount, 0);

  return completed / totalPossible;
}