import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../../auth/[...nextauth]/route";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const thread = await prisma.discussionThread.findUnique({
      where: {
        id: params.id,
        isHidden: false
      },
      include: {
        user: {
          select: {
            name: true
          }
        }
      }
    });

    if (!thread) {
      return NextResponse.json(
        { error: "Thread not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(thread);
  } catch (error) {
    console.error("[THREAD_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch thread" },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const thread = await prisma.discussionThread.findUnique({
      where: { id: params.id }
    });

    if (!thread) {
      return NextResponse.json(
        { error: "Thread not found" },
        { status: 404 }
      );
    }

    if (thread.userId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { error: "Not authorized" },
        { status: 403 }
      );
    }

    const { title, content, tags, isHidden } = await request.json();

    const updatedThread = await prisma.discussionThread.update({
      where: { id: params.id },
      data: {
        title,
        content,
        tags,
        isHidden,
        updatedAt: new Date()
      }
    });

    return NextResponse.json(updatedThread);
  } catch (error) {
    console.error("[THREAD_UPDATE]", error);
    return NextResponse.json(
      { error: "Failed to update thread" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const thread = await prisma.discussionThread.findUnique({
      where: { id: params.id }
    });

    if (!thread) {
      return NextResponse.json(
        { error: "Thread not found" },
        { status: 404 }
      );
    }

    if (thread.userId !== session.user.id && session.user.role !== 'admin') {
      return NextResponse.json(
        { error: "Not authorized" },
        { status: 403 }
      );
    }

    await prisma.discussionThread.delete({
      where: { id: params.id }
    });

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("[THREAD_DELETE]", error);
    return NextResponse.json(
      { error: "Failed to delete thread" },
      { status: 500 }
    );
  }
}