import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../../../auth/[...nextauth]/route";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "10");

  try {
    const [replies, total] = await Promise.all([
      prisma.discussionReply.findMany({
        where: {
          threadId: params.id,
          isHidden: false
        },
        include: {
          user: {
            select: {
              name: true
            }
          }
        },
        orderBy: {
          createdAt: 'asc'
        },
        take: limit,
        skip: (page - 1) * limit
      }),
      prisma.discussionReply.count({
        where: {
          threadId: params.id,
          isHidden: false
        }
      })
    ]);

    return NextResponse.json({
      replies,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("[REPLIES_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch replies" },
      { status: 500 }
    );
  }
}

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { content } = await request.json();

    const reply = await prisma.discussionReply.create({
      data: {
        content,
        threadId: params.id,
        userId: session.user.id
      }
    });

    return NextResponse.json(reply);
  } catch (error) {
    console.error("[REPLY_CREATE]", error);
    return NextResponse.json(
      { error: "Failed to create reply" },
      { status: 500 }
    );
  }
}