import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function GET(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const links = await prisma.partnerLink.findMany({
      where: { userId: session.user.id },
      include: {
        stats: {
          orderBy: { date: 'desc' },
          take: 30
        }
      }
    });

    return NextResponse.json(links);
  } catch (error) {
    console.error("[PARTNER_LINKS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch partner links" },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { description, rewardConfig } = await request.json();

    const link = await prisma.partnerLink.create({
      data: {
        userId: session.user.id,
        code: `${session.user.referralCode}-${Date.now()}`,
        description,
        rewardConfig
      }
    });

    return NextResponse.json(link);
  } catch (error) {
    console.error("[PARTNER_LINK_CREATE]", error);
    return NextResponse.json(
      { error: "Failed to create partner link" },
      { status: 500 }
    );
  }
}