import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function POST(request: Request) {
  try {
    const { categoryId, guestId } = await request.json();
    const session = await getServerSession(authOptions);

    if (session?.user) {
      // Update user preferences
      await prisma.userPreference.upsert({
        where: {
          userId_categoryId: {
            userId: session.user.id,
            categoryId
          }
        },
        update: {
          viewCount: { increment: 1 },
          lastViewedAt: new Date()
        },
        create: {
          userId: session.user.id,
          categoryId,
          viewCount: 1
        }
      });
    } else if (guestId) {
      // Update guest preferences
      await prisma.guestPreference.upsert({
        where: {
          guestId_categoryId: {
            guestId,
            categoryId
          }
        },
        update: {
          viewCount: { increment: 1 },
          lastViewedAt: new Date()
        },
        create: {
          guestId,
          categoryId,
          viewCount: 1
        }
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[TRACK_PREFERENCE]", error);
    return NextResponse.json(
      { error: "Failed to track preference" },
      { status: 500 }
    );
  }
}