import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../auth/[...nextauth]/route";

export async function GET() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  try {
    const habits = await prisma.habit.findMany({
      where: {
        userId: session.user.id
      },
      orderBy: {
        createdAt: "desc"
      }
    });

    return NextResponse.json(habits);
  } catch (error) {
    console.error("[HABITS_GET]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  try {
    const { name, description } = await request.json();

    const habit = await prisma.habit.create({
      data: {
        name,
        description,
        userId: session.user.id
      }
    });

    return NextResponse.json(habit);
  } catch (error) {
    console.error("[HABIT_CREATE]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
}