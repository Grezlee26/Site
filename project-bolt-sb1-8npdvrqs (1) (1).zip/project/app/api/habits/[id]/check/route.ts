import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../../auth/[...nextauth]/route";

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  try {
    const habit = await prisma.habit.findUnique({
      where: { id: params.id }
    });

    if (!habit || habit.userId !== session.user.id) {
      return new NextResponse("Not found", { status: 404 });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const lastChecked = habit.lastChecked ? new Date(habit.lastChecked) : null;
    const isNewStreak = !lastChecked || lastChecked < today;

    const updatedHabit = await prisma.habit.update({
      where: { id: params.id },
      data: {
        lastChecked: new Date(),
        streakCount: isNewStreak ? habit.streakCount + 1 : habit.streakCount
      }
    });

    return NextResponse.json(updatedHabit);
  } catch (error) {
    console.error("[HABIT_CHECK]", error);
    return new NextResponse("Internal error", { status: 500 });
  }
}