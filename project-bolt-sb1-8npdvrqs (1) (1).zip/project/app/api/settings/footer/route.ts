import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const [socialLinks, copyrightText] = await Promise.all([
      prisma.setting.findUnique({
        where: { key: "socialLinks" }
      }),
      prisma.setting.findUnique({
        where: { key: "copyrightText" }
      })
    ]);

    return NextResponse.json({
      socialLinks: socialLinks ? JSON.parse(socialLinks.value) : [],
      copyrightText: copyrightText?.value || "© {year} Modern AI Blog"
    });
  } catch (error) {
    console.error("[FOOTER_SETTINGS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch footer settings" },
      { status: 500 }
    );
  }
}