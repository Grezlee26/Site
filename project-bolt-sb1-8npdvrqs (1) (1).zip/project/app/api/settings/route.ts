import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const settings = await prisma.setting.findMany({
      where: {
        key: {
          in: ['siteName', 'bannerImage', 'funnelText', 'logo']
        }
      }
    });

    // Transform array of settings into an object
    const settingsObject = settings.reduce((acc, { key, value }) => ({
      ...acc,
      [key]: value
    }), {
      siteName: 'Modern AI Blog',
      bannerImage: 'https://images.unsplash.com/photo-1519681393784-d120267933ba',
      funnelText: 'Discover the future of content creation',
      logo: '/logo.png'
    });

    return NextResponse.json(settingsObject);
  } catch (error) {
    console.error("[SETTINGS_GET]", error);
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 });
  }
}