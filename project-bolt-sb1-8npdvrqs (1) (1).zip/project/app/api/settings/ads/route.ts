import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const [adHtmlCode, adEnabled, postListAdInterval] = await Promise.all([
      prisma.setting.findUnique({
        where: { key: "adHtmlCode" }
      }),
      prisma.setting.findUnique({
        where: { key: "adEnabled" }
      }),
      prisma.setting.findUnique({
        where: { key: "postListAdInterval" }
      })
    ]);

    return NextResponse.json({
      adHtmlCode: adHtmlCode?.value || "",
      adEnabled: adEnabled?.value === "true",
      postListAdInterval: parseInt(postListAdInterval?.value || "0", 10)
    });
  } catch (error) {
    console.error("[AD_SETTINGS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch ad settings" },
      { status: 500 }
    );
  }
}