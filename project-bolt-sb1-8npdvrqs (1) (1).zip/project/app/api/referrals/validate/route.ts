import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { code } = await request.json();

    // Find referrer by code
    const referrer = await prisma.user.findFirst({
      where: { referralCode: code }
    });

    if (!referrer) {
      return NextResponse.json(
        { error: "Invalid referral code" },
        { status: 400 }
      );
    }

    if (referrer.id === session.user.id) {
      return NextResponse.json(
        { error: "Cannot use own referral code" },
        { status: 400 }
      );
    }

    // Create referral record
    const referral = await prisma.referral.create({
      data: {
        referrerId: referrer.id,
        referredId: session.user.id,
        code,
        status: 'pending',
        rewardType: 'points',
        rewardAmount: 100 // Configurable reward amount
      }
    });

    // Update user's referred_by field
    await prisma.user.update({
      where: { id: session.user.id },
      data: { referredBy: code }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[REFERRAL_VALIDATE]", error);
    return NextResponse.json(
      { error: "Failed to process referral" },
      { status: 500 }
    );
  }
}