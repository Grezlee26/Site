import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.postView.create({
      data: {
        postId: params.id
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("[POST_VIEW]", error);
    return NextResponse.json(
      { error: "Failed to record view" },
      { status: 500 }
    );
  }
}