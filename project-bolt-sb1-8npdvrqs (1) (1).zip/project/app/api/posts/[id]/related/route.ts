import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    // Get related posts count from settings
    const setting = await prisma.setting.findUnique({
      where: { key: "related_posts_count" }
    });
    
    const limit = setting ? parseInt(setting.value, 10) : 3;

    // Get related posts using the custom function
    const posts = await prisma.$queryRaw`
      SELECT * FROM get_related_posts(${params.id}::uuid, ${limit})
    `;

    return NextResponse.json(posts);
  } catch (error) {
    console.error("[RELATED_POSTS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch related posts" },
      { status: 500 }
    );
  }
}