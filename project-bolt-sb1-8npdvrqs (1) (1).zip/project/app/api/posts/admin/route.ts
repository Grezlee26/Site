import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { prisma } from "@/lib/prisma"
import { authOptions } from "../../auth/[...nextauth]/route"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session || session.user.role !== "admin") {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    const posts = await prisma.post.findMany({
      orderBy: {
        createdAt: "desc"
      },
      select: {
        id: true,
        title: true,
        published: true,
        createdAt: true,
        author: {
          select: {
            name: true
          }
        }
      }
    })

    return NextResponse.json(posts)
  } catch (error) {
    console.error("[POSTS_GET]", error)
    return new NextResponse("Internal error", { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || session.user.role !== "admin") {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    const { id } = await request.json()

    if (!id) {
      return new NextResponse("Post ID is required", { status: 400 })
    }

    await prisma.post.delete({
      where: { id }
    })

    return new NextResponse(null, { status: 204 })
  } catch (error) {
    console.error("[POST_DELETE]", error)
    return new NextResponse("Internal error", { status: 500 })
  }
}