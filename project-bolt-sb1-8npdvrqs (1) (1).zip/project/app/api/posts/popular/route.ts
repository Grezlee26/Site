import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    // Get settings
    const [periodSetting, countSetting] = await Promise.all([
      prisma.setting.findUnique({
        where: { key: "popular_posts_period" }
      }),
      prisma.setting.findUnique({
        where: { key: "popular_posts_count" }
      })
    ]);

    const period = periodSetting?.value || "week";
    const limit = countSetting ? parseInt(countSetting.value, 10) : 6;

    // Get popular posts using the custom function
    const posts = await prisma.$queryRaw`
      SELECT * FROM get_popular_posts(${period}::text, ${limit}::integer)
    `;

    return NextResponse.json(posts);
  } catch (error) {
    console.error("[POPULAR_POSTS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch popular posts" },
      { status: 500 }
    );
  }
}