import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "6");
  const search = searchParams.get("search") || "";

  try {
    const posts = await prisma.post.findMany({
      where: {
        OR: [
          { 'title.en': { contains: search, mode: 'insensitive' } },
          { 'title.ru': { contains: search, mode: 'insensitive' } },
          { 'excerpt.en': { contains: search, mode: 'insensitive' } },
          { 'excerpt.ru': { contains: search, mode: 'insensitive' } }
        ],
        published: true
      },
      include: {
        author: {
          select: {
            name: true
          }
        },
        tags: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      },
      take: limit,
      skip: (page - 1) * limit,
      orderBy: {
        createdAt: 'desc'
      }
    });

    const total = await prisma.post.count({
      where: {
        OR: [
          { 'title.en': { contains: search, mode: 'insensitive' } },
          { 'title.ru': { contains: search, mode: 'insensitive' } },
          { 'excerpt.en': { contains: search, mode: 'insensitive' } },
          { 'excerpt.ru': { contains: search, mode: 'insensitive' } }
        ],
        published: true
      }
    });

    return NextResponse.json({
      posts,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error("[POSTS_GET]", error);
    return NextResponse.json(
      { error: "Failed to fetch posts" },
      { status: 500 }
    );
  }
}