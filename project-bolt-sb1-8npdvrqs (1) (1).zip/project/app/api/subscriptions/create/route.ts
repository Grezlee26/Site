import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { stripe, createCustomer, createSubscription } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { authOptions } from "../../auth/[...nextauth]/route";

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { tierId } = await request.json();

    const tier = await prisma.subscriptionTier.findUnique({
      where: { id: tierId }
    });

    if (!tier) {
      return NextResponse.json(
        { error: "Invalid subscription tier" },
        { status: 400 }
      );
    }

    // Create or get Stripe customer
    let stripeCustomerId = session.user.stripeCustomerId;
    if (!stripeCustomerId) {
      const customer = await createCustomer(session.user.email!);
      stripeCustomerId = customer.id;
      
      await prisma.user.update({
        where: { id: session.user.id },
        data: { stripeCustomerId }
      });
    }

    // Create Stripe subscription
    const subscription = await createSubscription(
      stripeCustomerId,
      tier.stripePriceId
    );

    return NextResponse.json({
      clientSecret: subscription.latest_invoice.payment_intent.client_secret
    });
  } catch (error) {
    console.error("[SUBSCRIPTION_CREATE]", error);
    return NextResponse.json(
      { error: "Failed to create subscription" },
      { status: 500 }
    );
  }
}