"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { LevelProgress } from "@/components/profile/level-progress";
import { AchievementsGrid } from "@/components/profile/achievements-grid";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

export default function ProfilePage() {
  const { data: session } = useSession();
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAchievements() {
      try {
        const response = await fetch("/api/achievements");
        if (!response.ok) throw new Error();
        const data = await response.json();
        setAchievements(data);
      } catch (error) {
        toast.error("Failed to load achievements");
      } finally {
        setLoading(false);
      }
    }

    if (session?.user) {
      loadAchievements();
    }
  }, [session]);

  if (!session) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-center text-muted-foreground">
          Please sign in to view your profile
        </p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">My Profile</h1>

      <div className="space-y-12">
        <Card className="p-6">
          <LevelProgress points={session.user.points || 0} />
        </Card>

        <div>
          <h2 className="text-2xl font-bold mb-6">Achievements</h2>
          {loading ? (
            <div>Loading achievements...</div>
          ) : (
            <AchievementsGrid achievements={achievements} />
          )}
        </div>
      </div>
    </div>
  );
}