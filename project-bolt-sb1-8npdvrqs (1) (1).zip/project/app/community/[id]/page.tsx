"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { DiscussionThread, DiscussionReply } from "@/lib/types/discussion";
import { ReplyList } from "@/components/community/reply-list";
import { ReplyForm } from "@/components/community/reply-form";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart } from "lucide-react";
import { toast } from "sonner";

export default function ThreadPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { data: session } = useSession();
  const [thread, setThread] = useState<DiscussionThread | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadThread() {
      try {
        const response = await fetch(`/api/community/threads/${params.id}`);
        if (!response.ok) throw new Error();
        const data = await response.json();
        setThread(data);
      } catch (error) {
        toast.error("Failed to load thread");
        router.push("/community");
      } finally {
        setLoading(false);
      }
    }

    loadThread();
  }, [params.id, router]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!thread) return null;

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Discussions
        </Button>

        <div className="space-y-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold mb-2">{thread.title}</h1>
              <p className="text-sm text-muted-foreground">
                Posted by {thread.user?.name || "Anonymous"} on{" "}
                {new Date(thread.createdAt).toLocaleDateString()}
              </p>
            </div>
            <Button variant="ghost" size="sm">
              <Heart className="w-4 h-4 mr-2" />
              {thread.likesCount}
            </Button>
          </div>

          <div className="prose dark:prose-invert max-w-none">
            {thread.content}
          </div>

          {thread.tags.length > 0 && (
            <div className="flex gap-2">
              {thread.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 bg-secondary text-secondary-foreground rounded-md text-sm"
                >
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="border-t pt-8">
          <h2 className="text-2xl font-bold mb-6">
            Replies ({thread.repliesCount})
          </h2>
          <ReplyList threadId={thread.id} />
          {session ? (
            <ReplyForm threadId={thread.id} />
          ) : (
            <p className="text-center text-muted-foreground mt-8">
              Please sign in to reply
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
}