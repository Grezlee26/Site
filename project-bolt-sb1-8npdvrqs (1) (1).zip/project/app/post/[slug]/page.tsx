"use client"

import { useEffect, useState } from "react"
import { notFound } from "next/navigation"
import { PostContent } from "@/components/post-content"
import { PostHeader } from "@/components/post-header"
import { TagList } from "@/components/tag-list"
import { Skeleton } from "@/components/ui/skeleton"

interface Post {
  id: string
  title: string
  content: string
  featuredImage: string
  tags: Array<{ id: string; name: string; slug: string }>
}

export default function PostPage({ params }: { params: { slug: string } }) {
  const [post, setPost] = useState<Post | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchPost = async () => {
      try {
        const res = await fetch(`/api/posts/${params.slug}`)
        if (!res.ok) {
          throw new Error("Post not found")
        }
        const data = await res.json()
        setPost(data)
      } catch (error) {
        notFound()
      } finally {
        setLoading(false)
      }
    }

    fetchPost()
  }, [params.slug])

  if (loading) {
    return <PostSkeleton />
  }

  if (!post) {
    return notFound()
  }

  return (
    <article className="min-h-screen">
      <PostHeader title={post.title} image={post.featuredImage} />
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <PostContent content={post.content} />
        <div className="mt-8 pt-8 border-t">
          <TagList tags={post.tags} />
        </div>
      </div>
    </article>
  )
}

function PostSkeleton() {
  return (
    <div>
      <Skeleton className="w-full h-[50vh]" />
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <Skeleton className="h-12 w-3/4 mb-8" />
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-4 w-full" />
          ))}
        </div>
      </div>
    </div>
  )
}