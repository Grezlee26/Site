"use client"

import { useEffect, useState } from "react"
import { notFound } from "next/navigation"
import { PostGrid } from "@/components/post-grid"

interface Category {
  id: string
  name: string
  description?: string
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const [category, setCategory] = useState<Category | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadCategory() {
      try {
        const { data } = await supabase
          .from('tags')
          .select('id, name, description')
          .eq('slug', params.slug)
          .single()

        if (!data) {
          notFound()
        }

        setCategory(data)
      } catch (error) {
        notFound()
      } finally {
        setLoading(false)
      }
    }

    loadCategory()
  }, [params.slug])

  if (loading) {
    return <div>Loading...</div>
  }

  if (!category) {
    return notFound()
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">{category.name}</h1>
        {category.description && (
          <p className="text-lg text-muted-foreground">{category.description}</p>
        )}
      </div>
      <PostGrid searchQuery={`category:${params.slug}`} />
    </div>
  )
}